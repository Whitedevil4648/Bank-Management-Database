file = open("balance.txt","r")
for line in file:
    if line.split()[0] == 'a':
        balen = str(line.split()[1])
file.close()
#balance problem
print(balen)